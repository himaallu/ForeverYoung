import app from "../src/index";

export default app;
