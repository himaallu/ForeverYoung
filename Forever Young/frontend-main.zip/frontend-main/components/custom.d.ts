declare module "*.pdf" {
  const content: any;
  export default content;
}
